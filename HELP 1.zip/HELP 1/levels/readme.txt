will update this later.
not a complete list!!!!

0 = air ( spaces will act as air too )

! = invisible block collider ( used to stop player from falling at start of level)
a = broken bricks
l = ladder type bricks
b = breakable bricks
? = coin block
c = coin
@ = starting player location
m = powerup (mushroom will come out if mario is small and fire flower will come out if mario is big)
x = goomba enemy

F = level end flag pole.

q,w,e = small ,big, large pipes respectvly

QWER = BACKGROUND TILES
