version= 2020/5/11
author = Utkrist Karki, Realskull
framework name = [HELPv1] 

=====CHANGES=====
[+] Added a bomber powerup! Use x to shoot bombs.
[+] Added a level editor. Read leveleditor.txt for info
[0] Fixed a bug with sounds not playing and level issues.
==================

state = fully playable first level

No copyright on the framework. Feel free to modify and change according to your needs. If you do keep the code same, don't mind giving me some credits.

=================================

*no bugs yet (i hope)

only 1 level for now
THAT 1 LEVEL IS THE ORIGNAL LEVEL

==================================
CONTROLS
up arrow - jump
w- left move
d - right move
x - throw fireball

rip my english