version= 2020/5/8
author = Utkrist Karki, Realskull
framework name = [HELPv1] 

state = fully playable first level

No copyright on the framework. Feel free to modify and change according to your needs. If you do keep the code same, don't mind giving me some credits.

=================================

*no bugs yet (i hope)

only 1 level for now
THAT 1 LEVEL IS THE ORIGNAL LEVEL

==================================
CONTROLS
up arrow - jump
w- left move
d - right move
x - throw fireball

rip my english